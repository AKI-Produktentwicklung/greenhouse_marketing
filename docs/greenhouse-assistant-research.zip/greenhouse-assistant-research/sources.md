# Quellen

## Interne Quelle

### GA_Präsentation.pdf
Ältere Produktdokumentation des Greenhouse Assistant.

Enthält:
- Grundbeschreibung
- Controller-Konzept
- Sensoren
- Aktoren
- Systemübersicht
- Erdreichwärmetauscher

## Externe Recherche

Diese Datei soll während der Marktanalyse gepflegt werden.

Empfohlenes Format:

| Datum | Quelle | Thema | Kernaussage | Link | Vertrauensniveau |
|---|---|---|---|---|---|
| YYYY-MM-DD | Hersteller / Forum / Studie | Wettbewerb | ... | ... | hoch/mittel/niedrig |

## Quellenregeln

- Herstellerdaten für Preise und Funktionen bevorzugen
- Marktgrößen möglichst aus Verbänden, Behörden oder seriösen Studien
- Community-Quellen für Pain Points und Erfahrungsberichte verwenden
- einzelne Reddit-/Forenbeiträge nicht als Marktgröße interpretieren
- Vermutungen klar als Hypothesen markieren
