# Wettbewerbsanalyse

## Ziel

Mindestens 20–30 reale Produkte und Anbieter erfassen.

Nicht nur direkte Wettbewerber betrachten, sondern auch Alternativen, mit denen Kunden das Problem heute lösen.

## Wettbewerber-Kategorien

### A. DIY / Open Source
Beispiele:
- Home Assistant
- Node-RED
- ESPHome
- Arduino / ESP32 Eigenbau

Bewertung:
- sehr flexibel
- geringe Hardwarekosten
- hoher Integrations- und Wartungsaufwand

### B. Grow-Controller
Typische Merkmale:
- Indoor-Grow-Fokus
- Temperatur / Feuchte / Licht / Bewässerung
- teilweise App-Anbindung

Offene Frage:
- Wie gut eignen sie sich für echte Gewächshäuser mit Wind, Regen, Frost und Außenklima?

### C. Kleine Gewächshauscontroller
Zu recherchieren:
- Bartlett
- Link4
- NIDO
- Growlink
- Trellis Controls
- weitere europäische Anbieter

### D. Professionelle Systeme
Beispiele:
- Priva
- Argus
- Hoogendoorn
- Ridder

Bewertung:
- hoher Funktionsumfang
- professionelle Zielgruppe
- meist deutlich oberhalb des Zielsegments

## Vergleichskriterien

Für jeden Anbieter erfassen:

| Kriterium | Beschreibung |
|---|---|
| Zielgruppe | Hobby / Semi-Pro / Professional |
| Preis | Controller / Komplettsystem |
| Fläche / Zonen | unterstützte Größe |
| Sensorik | Temperatur, Feuchte, Wind etc. |
| Aktorik | Lüfter, Fenster, Heizung etc. |
| lokale Autonomie | funktioniert ohne Cloud? |
| Remote-Zugriff | Web / App |
| Logging | ja / nein |
| Wetterprognose | ja / nein |
| Ausfallsicherheit | Fallback / Safe Mode |
| Erweiterbarkeit | kabelgebunden / drahtlos |
| Installation | DIY / Fachbetrieb |
| Service | Support / Fernwartung |
| Schwächen | aus Reviews und Foren |
| Preismodell | Einmalpreis / Abo |

## Noch zu erledigen

- [ ] 20–30 Wettbewerber recherchieren
- [ ] Preisanker sammeln
- [ ] Kundenreviews auswerten
- [ ] Funktionslücken dokumentieren
- [ ] direkte vs. indirekte Wettbewerber trennen
- [ ] DACH-Anbieter besonders gewichten
