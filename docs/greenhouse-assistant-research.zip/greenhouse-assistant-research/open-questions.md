# Offene Fragen

## Markt

- Wie viele hochwertige private Gewächshäuser gibt es in DACH?
- Wie viele davon liegen im Investitionsbereich >5.000 EUR?
- Wie viele Besitzer automatisieren heute bereits?
- Welche Regionen sind besonders attraktiv?
- Wie groß ist das Segment kleiner gewerblicher Produzenten?

## Kunde

- Welcher Pain ist kaufentscheidend?
- Wie stark ist „Abwesenheit“ wirklich?
- Wird Schutz vor Sturm/Frost als Versicherungsnutzen verstanden?
- Wie viel Wert hat stabile Feuchtigkeit?
- Welche Funktionen werden als Pflicht betrachtet?

## Preis

- Wo liegt die optimale Einstiegsschwelle?
- Wie hoch darf ein typischer Vollausbau kosten?
- Wie hoch ist akzeptierte monatliche Servicegebühr?
- Gibt es unterschiedliche Preisgrenzen privat / gewerblich?

## Wettbewerb

- Welche Systeme sind direkte Wettbewerber?
- Welche Anbieter dominieren in DACH?
- Welche Funktionen fehlen bestehenden Produkten?
- Welche Beschwerden wiederholen sich?

## Vertrieb

- Direktvertrieb?
- Gewächshaushersteller als Partner?
- Händler?
- Installationspartner?
- Online-Shop?

## Business

- Welche Bruttomarge ist realistisch?
- Wie hoch sind Supportkosten pro Kunde?
- Wie viele Installationen pro Jahr sind nötig?
- Wann ist ein Vollzeit-Unternehmen tragfähig?
