# Marktanalyse

## Leitfrage

Gibt es im DACH- bzw. europäischen Markt genügend Kunden, die für eine autonome Gewächshaussteuerung im Bereich von etwa 1.000–3.000 EUR oder mehr bezahlen?

## Arbeitshypothese

Zwischen zwei Marktenden scheint eine Lücke zu bestehen:

### Unteres Ende
DIY- und Smart-Home-Lösungen:

- ESP32 / Arduino
- Home Assistant
- Node-RED
- WLAN-Steckdosen
- Einzelthermostate
- einfache Grow-Controller

Vorteile:
- günstig
- flexibel

Nachteile:
- hoher Eigenaufwand
- fehlende Systemverantwortung
- oft keine echte Ausfallsicherheit
- unterschiedliche Hersteller und Apps
- für normale Anwender schwer wartbar

### Oberes Ende
Professionelle Gartenbauautomation:

- Klima-Computer
- professionelle Bewässerungs- und Fertigationssysteme
- industrielle Sensorik und Aktorik
- Service- und Integrationsleistungen

Vorteile:
- robust
- bewährt
- skalierbar

Nachteile:
- teuer
- oft überdimensioniert
- für kleine Gewächshäuser zu komplex
- häufig Installations- und Serviceabhängigkeit

## Vermutete Marktlücke

Zielbereich:

> Hochwertige kleine Gewächshäuser und kleine gewerbliche Anlagen, die mehr Zuverlässigkeit und Autonomie benötigen als Smart-Home-Lösungen bieten, aber keine klassische professionelle Gewächshausautomation rechtfertigen.

## Relevante Marktsegmente

Priorität 1:
- ambitionierte private Gewächshausbesitzer
- Selbstversorger mit hochwertigem Gewächshaus
- Besitzer von Ganzjahresgewächshäusern

Priorität 2:
- kleine Direktvermarkter
- Market Farmer
- kleine Gemüsebaubetriebe

Weitere mögliche Segmente:
- Gastronomie / Farm-to-table
- Schulen, Bildung, Demonstrationsanlagen
- kleine Spezialkulturen
- hochwertige Wintergärten bzw. Sonderanwendungen

## Marktannahmen, die validiert werden müssen

1. Kunden mit Gewächshäusern ab ca. 5.000 EUR akzeptieren zusätzliche Investitionen in Automation.
2. Ein Systempreis von ca. 1.000–3.000 EUR ist für einen Teil des Marktes plausibel.
3. Abwesenheit und Risikoschutz sind stärkere Kaufargumente als reine Komfortfunktionen.
4. Kleine gewerbliche Betriebe bewerten Arbeitszeitersparnis und Ertragssicherheit höher als private Nutzer.
5. Kunden wünschen eher ein funktionierendes Gesamtsystem als eine Sammlung einzelner Smart-Home-Komponenten.
6. Service, Fernwartung und Support erhöhen die Zahlungsbereitschaft.
7. Wiederkehrende Erlöse über Cloud-/Servicefunktionen sind akzeptabel, wenn der Grundbetrieb lokal und ohne Abo möglich bleibt.

## Nächste Recherche

- Anzahl hochwertiger privater Gewächshäuser in DACH
- Marktvolumen für Gewächshauszubehör und Automation
- typische Gewächshauspreise
- installierte Basis bei Premium-Herstellern
- Anzahl kleiner Direktvermarkter / Market Farmer
- Preisniveaus konkurrierender Steuerungen
- Kundenbewertungen und häufige Beschwerden
